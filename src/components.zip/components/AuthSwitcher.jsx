import React from "react";
import ThemeImage from "./ThemeImage";

export default function AuthSwitcher({setView}) { //state: Login, SignupUser, SignupHos
 return(
    <>
    <div class="top-buttons">
        <div>
            <button 
            onClick={()=>{setView('login')}}>
                Login</button>
        </div>
        <div>
             <button onClick={()=>{setView('signupUser')}}>Signup User</button>
             <button onClick={()=>{setView('signupHospital')}}>Signup Hospital</button>
        </div>
    </div>
    </>
 )
}
