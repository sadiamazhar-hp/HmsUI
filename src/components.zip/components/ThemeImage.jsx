import React from "react";

export default function ThemeImage({setView}){
    return(
        <>
        <div className={`theme-image ${setView === 'signupUser' || setView === 'signupHospital' ? 'slide-left' : ''}`}>
            <h2 className="text-2xl font-bold">HOSPITAL MANAGEMENT SYSTEM!</h2>
        </div>
        </>
    )
}