import React from "react";

export default function LoginForm() {
  return (
    <div class="half">
        <div class="form-box">
          <h3>Login</h3>
          <input placeholder="Email" /><br /><br />
          <input placeholder="Password" type="password" /><br /><br />
          <button>Login</button>
        </div>
    </div>
  );
}
