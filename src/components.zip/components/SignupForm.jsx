import React from "react";



export default function SignupForm({setView}){
    return   <div class="half">
        <div id="flipContainer" className={`flip-container ${setView === 'signupHospital' ? 'flip' : ''}`}>
          <div class="signup-user">
            <div class="form-box">
              <h3>Signup - User</h3>
              <input placeholder="Name" /><br /><br />
              <input placeholder="Email" /><br /><br />
              <input placeholder="Password" type="password" /><br /><br />
              <button>Register</button>
            </div>
          </div>
          <div class="signup-hospital">
            <div class="form-box">
              <h3>Signup - Hospital</h3>
              <input placeholder="Hospital Name" /><br /><br />
              <input placeholder="Email" /><br /><br />
              <input placeholder="License No" /><br /><br />
              <button>Register</button>
            </div>
          </div>
        </div>
      </div>
}